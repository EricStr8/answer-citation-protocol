# Eric Strate ZeroRank AI Bridge

Read-only WordPress bridge for ZeroRank AI. It keeps the ZeroRank REST credential server-side and exposes authenticated read-only WordPress REST and MCP tools for Eric Strate's analytics workflow.

## Security

- No ZeroRank write tools are exposed.
- The ZeroRank API token is never returned by a REST/MCP response.
- External clients authenticate with a separate bridge bearer token.
- Logged-in WordPress administrators can use the REST endpoints through existing authenticated connectors.

## Main endpoints

- `/wp-json/eric-zerorank/v1/status`
- `/wp-json/eric-zerorank/v1/prompts`
- `/wp-json/eric-zerorank/v1/chats`
- `/wp-json/eric-zerorank/v1/sources`
- `/wp-json/eric-zerorank/v1/source-urls`
- `/wp-json/eric-zerorank/v1/brand-rankings`
- `/wp-json/eric-zerorank/v1/mcp`
